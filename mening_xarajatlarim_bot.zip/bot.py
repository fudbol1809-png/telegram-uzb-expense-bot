
# bot.py
# "Mening xarajatlarim bot" - Telegram-only Uzbek expense tracker
# Python 3.9+
# Requirements: python-telegram-bot==20.3 pandas matplotlib(optional)
#
# Set TELEGRAM_BOT_TOKEN env var before running.
# Optional: set ADMIN_IDS env var (comma-separated) to enable /admin.
#
# Run: python bot.py

import os
import logging
import sqlite3
import io
from datetime import datetime, date, timedelta, time
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters, CallbackQueryHandler, ConversationHandler

try:
    import pandas as pd
except Exception:
    pd = None

try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except Exception:
    MATPLOTLIB_AVAILABLE = False

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not TOKEN:
    raise SystemExit("Iltimos TELEGRAM_BOT_TOKEN muhit o'zgaruvchisini o'rnating.")

ADMIN_IDS = []
_admins = os.environ.get("ADMIN_IDS")
if _admins:
    try:
        ADMIN_IDS = [int(x.strip()) for x in _admins.split(",") if x.strip()]
    except:
        ADMIN_IDS = []

DB_PATH = "expenses_telegram.db"
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        amount INTEGER NOT NULL,
        category TEXT,
        note TEXT,
        created_at TEXT NOT NULL,
        user_id INTEGER,
        group_id INTEGER
    )""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        user_id INTEGER
    )""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        group_id INTEGER,
        period TEXT,
        amount INTEGER
    )""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        owner_id INTEGER
    )""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS group_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER,
        user_id INTEGER
    )""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS usersettings (
        user_id INTEGER PRIMARY KEY,
        reminder_hour INTEGER DEFAULT 20,
        reminder_enabled INTEGER DEFAULT 0
    )""")
    conn.commit()
    conn.close()

def add_record(user_id, typ, amount, category, note, group_id=None):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT INTO records (type, amount, category, note, created_at, user_id, group_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (typ, amount, category, note, datetime.utcnow().isoformat(), user_id, group_id))
    conn.commit()
    conn.close()

def list_categories(user_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT name FROM categories WHERE user_id=? ORDER BY name", (user_id,))
    rows = [r[0] for r in cur.fetchall()]
    conn.close()
    if not rows:
        return ["Taom","Transport","Uy","Boshqa"]
    return rows

def add_category(user_id, name):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT INTO categories (name, user_id) VALUES (?, ?)", (name, user_id))
    conn.commit()
    conn.close()

def set_limit(user_id, amount, period='month', group_id=None):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DELETE FROM limits WHERE user_id=? AND period=? AND group_id IS ?", (user_id, period, group_id))
    cur.execute("INSERT INTO limits (user_id, group_id, period, amount) VALUES (?, ?, ?, ?)", (user_id, group_id, period, amount))
    conn.commit()
    conn.close()

def get_limit(user_id, period='month', group_id=None):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT amount FROM limits WHERE user_id=? AND period=? AND group_id IS ?", (user_id, period, group_id))
    r = cur.fetchone()
    conn.close()
    return r[0] if r else None

def get_summary(user_id=None, period='today', group_id=None):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    if period=='today':
        day = date.today().isoformat()
        q = "SELECT type, SUM(amount) FROM records WHERE date(created_at)=? "
        params = [day]
        if user_id: q += "AND user_id=? "; params.append(user_id)
        if group_id is not None: q += "AND group_id=? "; params.append(group_id)
        q += " GROUP BY type"
        cur.execute(q, params)
    elif period in ('month','week','year'):
        if period=='month':
            ym = date.today().strftime("%Y-%m")
            q = "SELECT type, SUM(amount) FROM records WHERE substr(created_at,1,7)=? "
            params = [ym]
        elif period=='week':
            since = (date.today() - timedelta(days=6)).isoformat()
            q = "SELECT type, SUM(amount) FROM records WHERE date(created_at)>=? "
            params = [since]
        else:
            y = date.today().strftime("%Y")
            q = "SELECT type, SUM(amount) FROM records WHERE substr(created_at,1,4)=? "
            params = [y]
        if user_id: q += "AND user_id=? "; params.append(user_id)
        if group_id is not None: q += "AND group_id=? "; params.append(group_id)
        q += " GROUP BY type"
        cur.execute(q, params)
    rows = cur.fetchall()
    conn.close()
    return rows

def records_df(user_id=None, group_id=None):
    conn = sqlite3.connect(DB_PATH)
    if user_id:
        df = pd.read_sql_query("SELECT id, type, amount, category, note, created_at FROM records WHERE user_id=? ORDER BY created_at DESC", conn, params=(user_id,))
    elif group_id is not None:
        df = pd.read_sql_query("SELECT id, type, amount, category, note, created_at FROM records WHERE group_id=? ORDER BY created_at DESC", conn, params=(group_id,))
    else:
        df = pd.read_sql_query("SELECT id, type, amount, category, note, created_at FROM records ORDER BY created_at DESC", conn)
    conn.close()
    return df

def create_group(name, owner_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT INTO groups (name, owner_id) VALUES (?, ?)", (name, owner_id))
    group_id = cur.lastrowid
    cur.execute("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)", (group_id, owner_id))
    conn.commit()
    conn.close()
    return group_id

def join_group(group_id, user_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM group_members WHERE group_id=? AND user_id=?", (group_id, user_id))
    if cur.fetchone():
        conn.close()
        return False
    cur.execute("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)", (group_id, user_id))
    conn.commit()
    conn.close()
    return True

def get_group_members(group_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT user_id FROM group_members WHERE group_id=?", (group_id,))
    rows = [r[0] for r in cur.fetchall()]
    conn.close()
    return rows

def get_user_setting(user_id, key):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT reminder_hour, reminder_enabled FROM usersettings WHERE user_id=?", (user_id,))
    r = cur.fetchone()
    conn.close()
    if not r:
        return 20 if key=='reminder_hour' else 0
    mapping = {'reminder_hour': r[0], 'reminder_enabled': r[1]}
    return mapping.get(key, None)

def set_user_setting(user_id, key, value):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO usersettings (user_id, reminder_hour, reminder_enabled) VALUES (?, COALESCE((SELECT reminder_hour FROM usersettings WHERE user_id=?),20), COALESCE((SELECT reminder_enabled FROM usersettings WHERE user_id=?),0))",
                (user_id, user_id, user_id))
    if key=='reminder_hour':
        cur.execute("UPDATE usersettings SET reminder_hour=? WHERE user_id=?", (int(value), user_id))
    elif key=='reminder_enabled':
        cur.execute("UPDATE usersettings SET reminder_enabled=? WHERE user_id=?", (1 if value else 0, user_id))
    conn.commit()
    conn.close()

AMOUNT, CATEGORY, NOTE = range(3)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = f"Assalomu alaykum, {user.first_name}!\n\nMen: 'Mening xarajatlarim bot'.\nBuyruqlar:\n/add - interaktiv xarajat\n/income 500000 - daromad qo'shish\n/addcategory Taom - yangi toifa\n/categories - toifalar\n/report [today|week|month|year] - hisobot\n/stats - kategoriya tahlili\n/setlimit 2000000 - oy uchun limit\n/reminder on/off/hour - eslatmalar\n/group create NAME - guruh yarat\n/group join ID - guruhga qo'shilish\n/export - CSV\n/admin - admin panel (agar siz admin bo'lsangiz)\n"
    await update.message.reply_text(text)

async def quick_add_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txt = update.message.text.strip()
    parts = txt.split(maxsplit=2)
    if parts and parts[0].lower() in ("add","/add","expense","xarajat"):
        if len(parts)>=2 and parts[1].isdigit():
            amount = int(parts[1])
            category = parts[2] if len(parts)==3 else "Umumiy"
            add_record(update.effective_user.id, "expense", amount, category, "")
            limit = get_limit(update.effective_user.id, 'month')
            if limit:
                rows = get_summary(update.effective_user.id, period='month')
                exp = 0
                for t,s in rows:
                    if t=='expense': exp = s or 0
                if exp >= 0.8*limit:
                    await update.message.reply_text(f"⚠️ Diqqat: oy uchun limitning 80% ga yetildi. Limit: {limit} so'm")
            await update.message.reply_text(f"✅ Saqlandi: {amount} so'm — {category}")
            return
    if parts and parts[0].lower() in ("income","/income","daromad"):
        if len(parts)>=2 and parts[1].isdigit():
            amount = int(parts[1])
            note = parts[2] if len(parts)==3 else ""
            add_record(update.effective_user.id, "income", amount, "Daromad", note)
            await update.message.reply_text(f"✅ Daromad saqlandi: {amount} so'm")
            return

async def add_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Xarajat miqdorini kiriting (misol: 50000):")
    return AMOUNT

async def add_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txt = update.message.text.strip()
    if not txt.isdigit():
        await update.message.reply_text("Iltimos faqat raqam kiriting.")
        return AMOUNT
    context.user_data['amount'] = int(txt)
    cats = list_categories(update.effective_user.id)
    keyboard = [[InlineKeyboardButton(c, callback_data=f"cat|{c}")] for c in cats]
    keyboard.append([InlineKeyboardButton("Yangi toifa qo'shish", callback_data="cat|__new__")])
    await update.message.reply_text("Toifani tanlang:", reply_markup=InlineKeyboardMarkup(keyboard))
    return ConversationHandler.END

async def category_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    if data=="cat|__new__":
        await query.message.reply_text("Yangi toifa nomini yuboring:")
        return
    _, cat = data.split("|",1)
    context.user_data['category'] = cat
    await query.message.reply_text("Qo'shimcha eslatma (ixtiyoriy). '-' yozsangiz bo'ladi:")
    return

async def add_category_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cat = update.message.text.strip()
    context.user_data['category'] = cat
    await update.message.reply_text("Qo'shimcha eslatma (ixtiyoriy). '-' yozsangiz bo'ladi:")
    return NOTE

async def add_note_and_save(update: Update, context: ContextTypes.DEFAULT_TYPE):
    note = update.message.text.strip()
    amount = context.user_data.get('amount')
    category = context.user_data.get('category','Umumiy')
    if note == "-": note = ""
    add_record(update.effective_user.id, "expense", amount, category, note)
    await update.message.reply_text(f"✅ Saqlandi: {amount} so'm — {category}")
    context.user_data.clear()
    return ConversationHandler.END

async def income_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args and context.args[0].isdigit():
        amount = int(context.args[0])
        note = " ".join(context.args[1:]) if len(context.args)>1 else ""
        add_record(update.effective_user.id, "income", amount, "Daromad", note)
        await update.message.reply_text(f"✅ Daromad qo'shildi: {amount} so'm")
    else:
        await update.message.reply_text("Foydalanish: /income 500000 maosh")

async def addcategory_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name = " ".join(context.args)
    if not name:
        await update.message.reply_text("Foydalanish: /addcategory Taom")
        return
    add_category(update.effective_user.id, name)
    await update.message.reply_text(f"✅ Toifa qo'shildi: {name}")

async def categories_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cats = list_categories(update.effective_user.id)
    await update.message.reply_text("Sizning toifalaringiz:\n" + "\n".join(f"- {c}" for c in cats))

async def report_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    arg = context.args[0].lower() if context.args else "today"
    period = 'month' if arg=='month' else ('week' if arg=='week' else ('year' if arg=='year' else 'today'))
    rows = get_summary(update.effective_user.id, period=period)
    total_exp = 0
    total_inc = 0
    for typ, summ in rows:
        if typ=='expense': total_exp = summ or 0
        if typ=='income': total_inc = summ or 0
    text = f"Hisobot ({period}):\nDaromad: {total_inc} so'm\nXarajat: {total_exp} so'm\nBalans: { (total_inc or 0) - (total_exp or 0) } so'm"
    await update.message.reply_text(text)

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    ym = date.today().strftime("%Y-%m")
    cur = conn.cursor()
    cur.execute("SELECT category, SUM(amount) FROM records WHERE substr(created_at,1,7)=? AND type='expense' AND user_id=? GROUP BY category", (ym, update.effective_user.id))
    rows = cur.fetchall()
    conn.close()
    if not rows:
        await update.message.reply_text("Bu oy uchun xarajat topilmadi.")
        return
    cats = [r[0] or 'Umumiy' for r in rows]
    sums = [r[1] or 0 for r in rows]
    lines = [f"{c}: {s} so'm" for c,s in zip(cats,sums)]
    await update.message.reply_text("Bu oy kategoriya bo'yicha:\n" + "\n".join(lines))
    if MATPLOTLIB_AVAILABLE:
        fig, ax = plt.subplots()
        ax.pie(sums, labels=cats, autopct='%1.1f%%')
        buf = io.BytesIO()
        plt.savefig(buf, bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)
        await context.bot.send_photo(update.effective_user.id, photo=buf)

async def setlimit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args or not context.args[0].isdigit():
        await update.message.reply_text("Foydalanish: /setlimit 2000000 (oylik limit so'mda)")
        return
    amount = int(context.args[0])
    set_limit(update.effective_user.id, amount, period='month')
    await update.message.reply_text(f"✅ Oylik limit o'rnatildi: {amount} so'm")

async def reminder_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Foydalanish: /reminder on yoki /reminder off yoki /reminder hour 21")
        return
    if context.args[0].lower()=='on':
        set_user_setting(update.effective_user.id, 'reminder_enabled', 1)
        await update.message.reply_text("✅ Eslatmalar yoqildi.")
    elif context.args[0].lower()=='off':
        set_user_setting(update.effective_user.id, 'reminder_enabled', 0)
        await update.message.reply_text("✅ Eslatmalar o'chirildi.")
    elif context.args[0].lower()=='hour' and len(context.args)>=2 and context.args[1].isdigit():
        h = int(context.args[1])%24
        set_user_setting(update.effective_user.id, 'reminder_hour', h)
        await update.message.reply_text(f"✅ Eslatma soati o'rnatildi: {h}:00")
    else:
        await update.message.reply_text("Noto'g'ri format.")

async def group_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Foydalanish: /group create NAME  yoki /group join ID")
        return
    if context.args[0].lower()=='create' and len(context.args)>=2:
        name = " ".join(context.args[1:])
        gid = create_group(name, update.effective_user.id)
        await update.message.reply_text(f"✅ Guruh yaratildi. ID: {gid}. Do'stlaringizga /group join {gid} deb yozishni ayting.")
    elif context.args[0].lower()=='join' and len(context.args)>=2:
        try:
            gid = int(context.args[1])
        except:
            await update.message.reply_text("Guruh ID raqam bo'lishi kerak.")
            return
        ok = join_group(gid, update.effective_user.id)
        if ok:
            await update.message.reply_text("✅ Guruhga qo'shildingiz.")
        else:
            await update.message.reply_text("Siz allaqachon guruh a'zosi yoki xato ID.")
    else:
        await update.message.reply_text("Noto'g'ri format.")

async def export_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if pd is None:
        await update.message.reply_text("CSV eksport uchun pandas kutubxonasi o'rnatilishi kerak.")
        return
    df = pd.read_sql_query("SELECT id, type, amount, category, note, created_at FROM records WHERE user_id=? ORDER BY created_at DESC", sqlite3.connect(DB_PATH), params=(update.effective_user.id,))
    if df.empty:
        await update.message.reply_text("Yozuvlar topilmadi.")
        return
    bio = io.BytesIO()
    df.to_csv(bio, index=False)
    bio.seek(0)
    await update.message.reply_document(document=bio, filename="expenses.csv")

async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("Siz admin emassiz.")
        return
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM records")
    total_rows = cur.fetchone()[0]
    cur.execute("SELECT SUM(amount) FROM records WHERE type='expense'")
    total_exp = cur.fetchone()[0] or 0
    cur.execute("SELECT COUNT(DISTINCT user_id) FROM records")
    users = cur.fetchone()[0]
    conn.close()
    await update.message.reply_text(f"Admin panel:\nJami yozuvlar: {total_rows}\nJami xarajat: {total_exp} so'm\nFoydalanuvchilar: {users}")

async def daily_reminder_job(context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT user_id, reminder_hour FROM usersettings WHERE reminder_enabled=1")
    rows = cur.fetchall()
    conn.close()
    for uid, hour in rows:
        try:
            await context.bot.send_message(uid, "Eslatma: Bugungi xarajatlaringizni kiritdingizmi? (misol: add 50000 kofe)")
        except Exception as e:
            logger.info("Remind failed for %s: %s", uid, e)

async def monthly_report_job(context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT DISTINCT user_id FROM records")
    rows = [r[0] for r in cur.fetchall()]
    conn.close()
    for uid in rows:
        rows = get_summary(uid, period='month')
        total_exp = 0
        total_inc = 0
        for typ,s in rows:
            if typ=='expense': total_exp = s or 0
            if typ=='income': total_inc = s or 0
        text = f"Oylik hisobot:\nDaromad: {total_inc} so'm\nXarajat: {total_exp} so'm\nBalans: { (total_inc or 0) - (total_exp or 0) } so'm"
        try:
            await context.bot.send_message(uid, text)
        except Exception as e:
            logger.info("Monthly report failed for %s: %s", uid, e)

def main():
    init_db()
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("income", income_cmd))
    app.add_handler(CommandHandler("addcategory", addcategory_cmd))
    app.add_handler(CommandHandler("categories", categories_cmd))
    app.add_handler(CommandHandler("report", report_cmd))
    app.add_handler(CommandHandler("stats", stats_cmd))
    app.add_handler(CommandHandler("setlimit", setlimit_cmd))
    app.add_handler(CommandHandler("reminder", reminder_cmd))
    app.add_handler(CommandHandler("group", group_cmd))
    app.add_handler(CommandHandler("export", export_cmd))
    app.add_handler(CommandHandler("admin", admin_cmd))
    conv = ConversationHandler(
        entry_points=[CommandHandler('add', add_start)],
        states={
            AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_amount)],
            CATEGORY: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_category_text)],
            NOTE: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_note_and_save)],
        },
        fallbacks=[]
    )
    app.add_handler(conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, quick_add_text))
    app.add_handler(CallbackQueryHandler(category_button))

    jq = app.job_queue
    jq.run_repeating(daily_reminder_job, interval=60*60, first=10)
    async def monthly_check(ctx):
        if date.today().day==1:
            await monthly_report_job(ctx)
    jq.run_daily(monthly_check, time=time(hour=1, minute=0))

    print("Bot ishga tushmoqda...")
    app.run_polling()

if __name__ == "__main__":
    main()
