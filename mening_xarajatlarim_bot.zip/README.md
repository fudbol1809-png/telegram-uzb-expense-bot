
# Mening xarajatlarim bot (Telegram-only)

Bu paket Telegram orqali ishlaydigan o'zbekcha xarajat-bot: "Mening xarajatlarim bot".

## Funksiyalar
- Xarajat va daromad qo'shish (tez: `add 50000 kofe`, yoki interaktiv `/add`)
- Toifalar: `/categories`, `/addcategory Taom`
- Hisobotlar: `/report today|week|month|year`
- Kategoriya tahlili: `/stats` (matplotlib o'rnatilgan bo'lsa diagramma yuboradi)
- Oylik limit: `/setlimit 2000000`
- Eslatma: `/reminder on/off/hour N`
- Guruh: `/group create NAME`, `/group join ID`
- CSV eksport: `/export`
- Admin panel: `/admin` (agar `ADMIN_IDS` muhit o'zgaruvchisiga sizning ID qo'yilgan bo'lsa)

## Ishga tushirish
1. Python 3.9+ o'rnating.
2. Virtual muhit:
   ```
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate   # Windows (PowerShell)
   ```
3. Paketlarni o'rnatish:
   ```
   pip install -r requirements.txt
   ```
4. Muayyan muhit o'zgaruvchilarni o'rnating:
   - `TELEGRAM_BOT_TOKEN` (BotFather'dan olingan token)
   - (ixtiyoriy) `ADMIN_IDS` (masalan: 123456789)
5. Botni ishga tushirish:
   ```
   python bot.py
   ```

## GitHub / Render uchun
- Ushbu papkani GitHub'ga yuklab, Render yoki boshqa hostingda `python bot.py` start command bilan ishga tushiring.
